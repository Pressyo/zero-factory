============
Zero Factory
============

Zero Factory is an app factory for zeroMQ apps. To use::

    #!/usr/bin/env python
    import sys
    from zeroFactory import appFactory
    from methods import *
    
    currentModule = sys.modules[__name__]
    routes = {
                'create': 'createFunction',
                'retrieve': 'retrieve'
              }
    bind = 'tcp://*:1234'

    app = appFactory.App(routes=routes, currentModule=currentModule, bind=bind)
    
    app.run()  # this will essentially serve forever until stopped
